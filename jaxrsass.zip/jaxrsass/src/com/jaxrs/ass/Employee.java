package com.jaxrs.ass;

 
public class Employee{
 
 int id;
 String EmpName; 
long NoEmpl;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getEmpName() {
	return EmpName;
}
public void setEmpName(String empName) {
	EmpName = empName;
}
public long getNoEmpl() {
	return NoEmpl;
}
public void setNoEmpl(long noEmpl) {
	NoEmpl = noEmpl;
}
public Employee(int id, String empName, long noEmpl) {
	super();
	this.id = id;
	EmpName = empName;
	NoEmpl = noEmpl;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
 
}
 