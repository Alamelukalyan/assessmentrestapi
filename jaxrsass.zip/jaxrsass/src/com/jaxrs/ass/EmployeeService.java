package com.jaxrs.ass;


	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;
	 
	
	 
	/*
	 * It is just a helper class which should be replaced by database implementation.
	 * It is not very well written class, it is just used for demonstration.
	 */
	public class EmployeeService {
	 
	 static HashMap<Integer,Employee> employeeIdMap=getEmployeeIdMap();
	 
	 
	 public EmployeeService() {
	  super();
	 
	  if(employeeIdMap==null)
	  {
	   employeeIdMap=new HashMap<Integer,Employee>();
	  // Creating some objects of Employee while initializing
	   Employee indiaEmployee=new Employee(1, "ram",10000);
	   Employee chinaEmployee=new Employee(4, "rahim",20000);
	   Employee nepalEmployee=new Employee(3, "nannu",8000);
	   Employee bhutanEmployee=new Employee(2, "nandhu",7000);
	 
	 
	   employeeIdMap.put(1,indiaEmployee);
	   employeeIdMap.put(4,chinaEmployee);
	   employeeIdMap.put(3,nepalEmployee);
	   employeeIdMap.put(2,bhutanEmployee);
	  }
	 }
	 
	 public List getAllEmployees()
	 {
	  List employees = new ArrayList(employeeIdMap.values());
	  return  employees;
	 }
	 
	 public Employee getEmployee(int id)
	 {
	  Employee employee= employeeIdMap.get(id);
	  return employee;
	 }
	 public Employee addEmployee(Employee employee)
	 {
	  employee.setId(employeeIdMap.size()+1);
	  employeeIdMap.put(employee.getId(), employee);
	  return employee;
	 }
	 
	 public Employee updateEmployee(Employee employee)
	 {
	  if(employee.getId()<=0)
	   return null;
	  employeeIdMap.put(employee.getId(), employee);
	  return employee;
	 
	 }
	 public void deleteEmployee(int id)
	 {
	  employeeIdMap.remove(id);
	 }
	 
	 public static HashMap<Integer, Employee> getEmployeeIdMap() {
	  return employeeIdMap;
	 }
	}
	
